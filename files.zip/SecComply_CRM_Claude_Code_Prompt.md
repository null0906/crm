# Claude Code Prompt — Implement Daily Digest + Telegram Bot

Read the file at `./SecComply_CRM_Features_Addendum.md` in full before writing any code. This is the complete specification for two new features being added to the existing SecComply CRM platform. The main CRM codebase already exists and follows the architecture in `./SecComply_CRM_Platform_Development_Prompt.md`.

## What You Are Building

Two integrated features:

1. **Telegram Bot** — A Telegram bot that lets sales reps add contacts, companies, log activities, search records, and view metrics by sending structured messages from their phone.

2. **Daily Dashboard Digest** — A scheduled system that sends dashboard snapshots via email and Telegram at configured times to configured recipients.

Both features share the Telegram Bot API infrastructure and integrate deeply with the existing CRM services (contacts, companies, activities, dashboards, tags, custom fields, audit log).

## Execution Order

### Step 1: Database Schema

Add three new Drizzle schema files to `src/server/db/schema/`:

1. `telegram-users.ts` — The `telegram_users` table (maps Telegram user IDs to CRM users). See Part 3 of the addendum for the exact schema.
2. `digest-schedules.ts` — The `digest_schedules` table (stores dashboard digest configurations with schedule, delivery channels, and status). See Part 3.
3. `telegram-message-log.ts` — The `telegram_message_log` table (logs every inbound/outbound bot interaction). See Part 3.

Add all three to the barrel export in `src/server/db/schema/index.ts`. Generate and run the Drizzle migration. Verify tables exist.

### Step 2: Telegram Bot Core Infrastructure

Create `src/server/lib/telegram-bot.ts` — a lightweight wrapper around the Telegram Bot API using native `fetch`. NO external Telegram bot libraries. Implement these functions exactly as specified in Part 10 of the addendum:
- `sendMessage(chatId, text, parseMode)`
- `getUpdates(offset?)` — for polling mode in development
- `setWebhook(url, secretToken)` — for production
- `getBotInfo()` — for connection testing

Create `src/server/lib/telegram-parser.ts` — the structured message parser. This is a set of pure functions with NO async and NO side effects:
- `parseStructuredMessage(rawText)` → `{ command, fields, errors }`
- `parseName(nameStr)` → `{ firstName, lastName }`
- `parseTags(tagStr)` → `string[]`
- `parsePhone(phoneStr)` → cleaned string
- `validateEmail(email)` → boolean
- `normalizeDomain(domain)` → cleaned string

Follow the exact parsing rules from Part 9:
- Split on newlines, first line is command, remaining lines are `key: value` pairs
- Split on FIRST colon only (values may contain colons)
- Keys are case-insensitive and trimmed
- Empty values are skipped silently
- Missing colons generate errors
- For `/find`: single argument after command, no key:value parsing
- For `/today`, `/mytasks`, `/help`, `/start`: no arguments

Write unit tests for the parser covering: valid messages, missing fields, malformed lines, edge cases (name with multiple spaces, tags with extra commas, phone with formatting characters).

### Step 3: Telegram Service

Create `src/server/services/telegram.service.ts` — the main command handler. This service:

1. Receives a parsed Telegram update (message text + sender info)
2. Authenticates the sender against the `telegram_users` table
3. Parses the message using `telegram-parser.ts`
4. Routes to the correct command handler
5. Executes the CRM operation using EXISTING services (contactService, companyService, activityService, etc.)
6. Formats the response message
7. Sends the response back via `telegram-bot.ts`
8. Logs the interaction to `telegram_message_log`

Implement ALL commands from Part 4 of the addendum:

**`/add`** — Create a contact. Parse name, title, company, email, phone, tags, notes, source, status. Look up company by name (case-insensitive), create if not found. Look up tags, create if not found. Set owner to the CRM user mapped to the sender. Use the existing `contactService.create()`. Return formatted success/error response.

**`/addcompany`** — Create a company. Parse name, domain, industry, size, type, phone, city, country, tags, notes. Normalize domain. Use existing `companyService.create()`.

**`/note`** — Log an activity. Parse contact (by email or name), type, subject, body, duration, outcome. Look up contact — if ambiguous, return disambiguation list. Use existing `activityService.create()`.

**`/log`** — Shorthand for `/note` with `type: call`.

**`/find`** — Search. Query contacts by email, then name. Query companies by name, then domain. Return the first match with full details including: associated company, tags, owner, last contacted, open deals count and value. Use existing search/query methods.

**`/today`** — Generate metrics summary. Query: total open pipeline value and count, weighted pipeline, won/lost this month, today's activity counts by type, stale deals count (no activity > 7 days), overdue tasks count, unassigned leads count, team leaderboard (top 5 by activity count this week). Format as the structured text block shown in Part 4.

**`/mytasks`** — Query activities where `activity_type = 'task'` AND `task_completed_at IS NULL` AND `performed_by = currentUser`, grouped by: overdue (due date < today), due today, upcoming (due date > today, limit 5). Format as the structured text block shown in Part 4.

**`/help`** — Return the static help text from Part 4.

**`/start`** — Return a welcome message: "Welcome to SecComply CRM Bot! Use /help to see available commands."

**Unknown commands** — Return: "Unknown command. Use /help to see available commands."

**Unauthorized senders** — Return: "Your Telegram account is not linked to a CRM user. Contact your admin to set up access."

Every command handler must:
- Log to `telegram_message_log` with direction='inbound', command, raw_message, parsed_data, result_status, result_message, entity_type, entity_id
- Write to audit_log for any data mutations (contact created, activity logged, etc.) with metadata `{ source: 'telegram' }`
- Handle errors gracefully — catch all exceptions, return user-friendly error messages, log the error

### Step 4: Webhook Endpoint

Create `src/app/api/webhooks/telegram/route.ts` — POST endpoint.

1. Validate `X-Telegram-Bot-Api-Secret-Token` header against `TELEGRAM_WEBHOOK_SECRET` env var. Return 403 if invalid.
2. Parse the request body as a Telegram Update object
3. Extract message text and sender info (`update.message.text`, `update.message.from.id`)
4. If no message text (e.g., sticker, photo), ignore and return 200
5. Call `telegramService.handleMessage(telegramUserId, messageText, senderInfo)`
6. Always return 200 OK to Telegram (even on errors — Telegram retries on non-200)

### Step 5: Polling Mode for Development

Create `src/server/lib/telegram-polling.ts` — a long-polling loop for local development:

1. On import/init, start a loop that calls `getUpdates(offset)` with 30-second timeout
2. For each update received, call the same `telegramService.handleMessage()` as the webhook
3. Update the offset to `lastUpdateId + 1`
4. Only start polling if `TELEGRAM_MODE=polling` in env

Wire this up in the Next.js server startup (e.g., via a custom server script or an instrumentation hook).

### Step 6: tRPC Routers for Admin UI

Create `src/server/trpc/routers/telegram.router.ts` with ALL procedures from Part 8:
- `listUsers`, `addUser`, `removeUser`, `toggleActive` — CRUD for telegram_users
- `getMessageLog` — paginated, filterable message log
- `testConnection` — calls `getBotInfo()` and returns success/failure
- `getBotStatus` — returns bot username, webhook status, last message timestamp

Create `src/server/trpc/routers/digest.router.ts` with ALL procedures from Part 8:
- `list`, `create`, `update`, `delete`, `toggleActive` — CRUD for digest_schedules
- `sendNow` — manually trigger a digest for testing

ALL procedures require admin permission (`settings.access` or a new `telegram.manage` permission). Add the new permission to the roles schema and seed data.

Register both routers in the root tRPC router.

### Step 7: Daily Digest Engine

Install dependencies:
```bash
npm install node-cron nodemailer
npm install -D @types/nodemailer @types/node-cron
```

Create `src/server/lib/mailer.ts` — Nodemailer wrapper:
- Configure transporter from SMTP env vars
- `sendEmail(to, subject, html)` function
- Error handling with retry (1 retry on failure)

Create `src/server/services/digest-renderer.ts` — two render functions:

1. `renderDigestEmail(dashboardId)` → returns `{ subject: string, html: string }`
   - Query dashboard and all its widgets using existing dashboard data engine
   - Render as clean HTML email:
     - Branded header (SecComply logo, dashboard name, timestamp)
     - Each widget rendered as HTML (metric cards as big numbers, charts as HTML tables, leaderboards as numbered lists)
     - Footer with link to live dashboard
   - Keep HTML email-client compatible (inline styles, table-based layout, no JS)

2. `renderDigestTelegram(dashboardId)` → returns `string`
   - Same data, formatted as structured plain text with emoji (see Part 5.2)
   - MUST stay under 4096 characters (Telegram message limit) — truncate tables/lists if needed

Create `src/server/services/digest.service.ts`:
- `sendDigest(scheduleId)` — loads schedule, renders content, delivers to all configured channels (email + telegram), updates `last_sent_at`, logs errors
- `checkAndRunSchedules()` — called by cron, loads all active schedules, checks if current IST time matches any schedule's time + type + day, runs matching ones

Create `src/server/lib/cron.ts`:
- Use `node-cron` to run `checkAndRunSchedules()` every minute
- Initialize on server startup
- Log cron execution for debugging

Wire up the cron in the Next.js instrumentation hook (`src/instrumentation.ts`) or a custom server entry point so it starts when the server starts.

### Step 8: Admin UI Pages

Create `src/app/(dashboard)/settings/telegram/page.tsx` — Telegram Integration settings page with three sections:

1. **Bot Status card** — Shows bot username, webhook status, last activity. "Test Connection" button.
2. **Authorized Users table** — List all telegram_users with CRM user name, Telegram ID, username, active status, last active date. "Add User" button opens a form: select CRM user from dropdown + enter Telegram ID. Toggle active/inactive. Remove button with confirmation.
3. **Message Log table** — Paginated, filterable log of all bot interactions. Columns: Timestamp, User, Command, Message Preview (truncated), Status badge, Entity link. Click row to expand full message and response.

Create `src/app/(dashboard)/settings/digests/page.tsx` — Digest Schedule management page:

1. **Schedule list** — Table of all configured digests: Name, Dashboard name, Schedule description (e.g., "Daily at 9:00 AM"), Channels (email badge count + telegram badge count), Last Sent, Status badge, Active toggle, Edit/Delete buttons.
2. **Create/Edit form** (modal or slide-over) — Fields: Name, Dashboard selector dropdown, Schedule type (daily/weekly/monthly), Time picker, Day picker (for weekly/monthly), Delivery channels section with:
   - Email recipients: Multi-input field for email addresses
   - Telegram recipients: Multi-select from authorized Telegram users + text input for group chat IDs
   - Active toggle
3. **"Send Now" button** on each schedule row — triggers immediate delivery for testing.

Add navigation items for both pages under Settings in the sidebar (only visible to admins).

### Step 9: Seed Data Updates

Update the seed script to include:
- Add `telegram.manage` and `digests.manage` permissions to the SuperAdmin and Sales Manager roles
- Optionally pre-create telegram_user mappings if Telegram IDs are known
- Create one default digest schedule (Daily Sales Overview at 09:00 IST, inactive until configured)

### Step 10: Testing

Write tests for:
- `telegram-parser.ts` — all parsing functions (unit tests, these are pure functions)
- `telegram.service.ts` — command routing and response formatting (integration tests with test DB)
- RBAC — non-admin cannot access telegram or digest settings
- Webhook endpoint — valid/invalid secret token handling
- Digest renderer — email output is valid HTML, telegram output is under 4096 chars

Run through the full testing checklist in Part 11 of the addendum manually.

## Critical Rules

1. NO external Telegram bot libraries (no `telegraf`, no `node-telegram-bot-api`). The Telegram API is simple REST — use native `fetch`. This keeps dependencies minimal and the code transparent.

2. The message parser (`telegram-parser.ts`) must be pure functions with NO side effects. It parses text and returns structured data. All CRM operations happen in the service layer.

3. Every bot interaction is logged to `telegram_message_log`. Every data mutation from the bot is logged to `audit_log` with `metadata.source = 'telegram'`.

4. The bot ONLY responds to authorized Telegram user IDs registered in the `telegram_users` table. All other senders get a rejection message.

5. The daily digest cron runs inside the Next.js process (not an external cron). This works on Railway where the process is long-lived. Use `node-cron`.

6. Telegram messages have a 4096 character limit. The `/today` command output and digest Telegram messages MUST respect this limit. Truncate gracefully if needed.

7. All admin UI pages are protected by RBAC — only SuperAdmin and Sales Manager can access Telegram settings and Digest settings.

8. Use EXISTING CRM services for all data operations. Do NOT write new database queries for creating contacts, companies, activities, or querying dashboard data. Call the service methods that already exist.

9. Handle all errors gracefully in the bot — no unhandled exceptions should crash the webhook handler. Always return 200 to Telegram. Log errors, send user-friendly error messages back.

10. Support both polling mode (development) and webhook mode (production) controlled by the `TELEGRAM_MODE` env var.

Start with Step 1. Build and verify each step before moving to the next.
