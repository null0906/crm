# SecComply CRM — Feature Addendum: Daily Dashboard Digest + Telegram Bot

> **Document Type:** Implementation Guide + Claude Code Prompt  
> **Companion to:** SecComply_CRM_Platform_Development_Prompt.md  
> **Date:** April 2026

---

## Part 1: Telegram Bot Setup (Do This First, Before Any Code)

### Step 1: Create the Telegram Bot

1. Open Telegram on your phone or desktop
2. Search for `@BotFather` (the official Telegram bot for creating bots — look for the blue verified checkmark)
3. Send `/newbot`
4. BotFather asks: "What name do you want for your bot?" — type: `SecComply CRM`
5. BotFather asks: "Choose a username for your bot" — type: `seccomply_crm_bot` (must end in `bot`, must be unique — if taken, try `seccomply_command_bot` or similar)
6. BotFather replies with your **bot token** — it looks like: `7123456789:AAHfiqksKZ8WmR4hMKSomeRandomString`
7. **Save this token.** You will add it to your CRM's `.env` file as `TELEGRAM_BOT_TOKEN`

### Step 2: Configure the Bot Profile

Still in the BotFather chat:

1. Send `/setdescription` → Select your bot → Type: `SecComply CRM Bot — Add leads, log activities, and get daily reports directly from Telegram.`
2. Send `/setabouttext` → Select your bot → Type: `Internal CRM bot for SecComply sales team. Use /help to see commands.`
3. Send `/setcommands` → Select your bot → Paste this exact block:

```
add - Add a new contact/lead
addcompany - Add a new company
note - Log a note against a contact
log - Log a call or meeting
find - Look up a contact or company
today - Get today's key metrics
mytasks - View your pending tasks
help - Show command formats and usage
```

This registers the command menu so users see autocomplete when they type `/` in the chat.

### Step 3: Get Chat IDs for Authorized Users

Each sales team member who will use the bot needs to be registered. You need their Telegram user IDs (numeric, not username).

**How to get a user's Telegram ID:**

1. Have each team member open the bot and send any message (e.g., `/start`)
2. Open this URL in your browser (replace YOUR_BOT_TOKEN):
   ```
   https://api.telegram.org/botYOUR_BOT_TOKEN/getUpdates
   ```
3. You'll see a JSON response. Look for `"from": { "id": 123456789 }` — that number is the user's Telegram ID
4. Record each team member's Telegram ID and their corresponding CRM user email:
   ```
   Atharva  → Telegram ID: XXXXXXXXX → atharva@seccomply.com
   Shivani  → Telegram ID: XXXXXXXXX → shivani@seccomply.com
   Aditi    → Telegram ID: XXXXXXXXX → aditi@seccomply.com
   Sanil    → Telegram ID: XXXXXXXXX → sanil@seccomply.com
   ```

You will enter these mappings in the CRM admin panel (Settings → Telegram Integration) once the feature is built.

### Step 4: Set the Webhook (After Deployment)

Once your CRM is deployed and accessible at a public URL (e.g., `https://crm.seccomply.com`), you register the webhook so Telegram sends incoming messages to your CRM:

```bash
curl -X POST "https://api.telegram.org/botYOUR_BOT_TOKEN/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://crm.seccomply.com/api/webhooks/telegram", "secret_token": "YOUR_WEBHOOK_SECRET"}'
```

The `secret_token` is a random string you generate (e.g., `openssl rand -hex 32`) and store in `.env` as `TELEGRAM_WEBHOOK_SECRET`. Telegram sends this in the `X-Telegram-Bot-Api-Secret-Token` header so your endpoint can verify the request is really from Telegram.

**Verify it worked:**
```bash
curl "https://api.telegram.org/botYOUR_BOT_TOKEN/getWebhookInfo"
```

Should show your URL with `"has_custom_certificate": false` and `"pending_update_count": 0`.

### Step 5: For Local Development (Before Deployment)

During development, your localhost isn't reachable from Telegram. Use polling mode instead:

The code (specified below) will support both modes:
- **Development:** Long-polling via `getUpdates` API (no webhook needed)
- **Production:** Webhook mode (Step 4 above)

You'll set `TELEGRAM_MODE=polling` in `.env.local` and `TELEGRAM_MODE=webhook` in production.

---

## Part 2: Environment Variables to Add

Add these to your `.env` file:

```env
# Telegram Bot
TELEGRAM_BOT_TOKEN=7123456789:AAHfiqksKZ8WmR4hMKSomeRandomString
TELEGRAM_WEBHOOK_SECRET=generate_a_random_64_char_hex_string_here
TELEGRAM_MODE=polling  # 'polling' for dev, 'webhook' for production

# Daily Digest Email (uses existing SMTP config from main spec)
# Add these if not already present:
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=crm@seccomply.com
SMTP_PASSWORD=your_app_password_here
SMTP_FROM_NAME=SecComply CRM
SMTP_FROM_EMAIL=crm@seccomply.com

# Daily Digest Telegram (uses same bot)
DIGEST_DEFAULT_TIME=09:00  # IST, 24hr format
```

---

## Part 3: Database Schema Additions

### `telegram_users` — Maps Telegram IDs to CRM Users

```sql
CREATE TABLE telegram_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    telegram_user_id BIGINT UNIQUE NOT NULL,  -- Telegram's numeric user ID
    telegram_username VARCHAR(100),            -- @username (optional, for display)
    telegram_first_name VARCHAR(100),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,  -- CRM user
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_telegram_users_tg_id ON telegram_users(telegram_user_id);
CREATE INDEX idx_telegram_users_user ON telegram_users(user_id);
```

### `digest_schedules` — Dashboard Digest Configuration

```sql
CREATE TABLE digest_schedules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(150) NOT NULL,
    
    -- What to send
    dashboard_id UUID NOT NULL REFERENCES dashboards(id) ON DELETE CASCADE,
    
    -- When to send
    schedule_type VARCHAR(20) NOT NULL DEFAULT 'daily'
        CHECK (schedule_type IN ('daily', 'weekly', 'monthly')),
    schedule_time TIME NOT NULL DEFAULT '09:00',  -- Time in IST
    schedule_day_of_week INTEGER,  -- 0=Sunday..6=Saturday (for weekly)
    schedule_day_of_month INTEGER, -- 1-28 (for monthly)
    timezone VARCHAR(50) DEFAULT 'Asia/Kolkata',
    
    -- Where to send
    delivery_channels JSONB NOT NULL DEFAULT '[]',
    -- [
    --   { "type": "email", "recipients": ["sanil@seccomply.com", "investor@example.com"] },
    --   { "type": "telegram", "chat_ids": [123456789, -100987654321] }
    -- ]
    -- chat_ids can be individual user IDs or group chat IDs (negative numbers)
    
    -- Status
    is_active BOOLEAN DEFAULT TRUE,
    last_sent_at TIMESTAMPTZ,
    last_error TEXT,
    
    -- Metadata
    created_by UUID NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_digest_schedules_active ON digest_schedules(is_active) WHERE is_active = TRUE;
```

### `telegram_message_log` — Log of All Bot Interactions

```sql
CREATE TABLE telegram_message_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    telegram_user_id BIGINT NOT NULL,
    user_id UUID REFERENCES users(id),
    direction VARCHAR(10) NOT NULL CHECK (direction IN ('inbound', 'outbound')),
    command VARCHAR(30),        -- '/add', '/find', '/today', etc.
    raw_message TEXT NOT NULL,
    parsed_data JSONB,          -- Structured data extracted from message
    result_status VARCHAR(20) NOT NULL CHECK (result_status IN ('success', 'error', 'unauthorized', 'invalid_format')),
    result_message TEXT,        -- Response sent back to user
    entity_type VARCHAR(20),    -- 'contact', 'company', 'activity' (if a record was created)
    entity_id UUID,             -- ID of created/found record
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_tg_log_user ON telegram_message_log(telegram_user_id);
CREATE INDEX idx_tg_log_created ON telegram_message_log(created_at DESC);
```

---

## Part 4: Telegram Bot — Command Specification

### Command: `/add` — Add a Contact

**Format sent by user:**
```
/add
name: Rajesh Sharma
title: CTO
company: InfraSec Solutions
email: rajesh@infrasec.in
phone: 9876543210
tags: ISO 27001, NASSCOM Event
notes: Met at NASSCOM Pune, interested in surveillance audit
source: event
status: contacted
```

**Required fields:** `name` (at minimum first name)  
**Optional fields:** All others. If omitted, they are left null/default.

**Parsing rules:**
- Split message by newlines
- First line is the command (`/add`) — skip it
- Each subsequent line is `key: value` — split on first `:` only (value may contain colons)
- Keys are case-insensitive, trimmed
- `name` is split into first_name + last_name on the last space (e.g., "Rajesh Kumar Sharma" → first: "Rajesh Kumar", last: "Sharma". If single word → first: word, last: empty)
- `tags` is split on commas, each tag trimmed, matched case-insensitively against existing tags, auto-created if not found
- `company` is looked up by exact name match (case-insensitive). If not found, a new company record is created with just the name. The new contact is linked to it.
- `source` must be one of: apollo, manual, website, referral, event, cold_outreach. Default: manual
- `status` must be one of: new, contacted, qualified, unqualified, nurturing. Default: new
- `phone` — strip all non-digit characters except leading +
- `email` — basic format validation (contains @)
- Owner is auto-set to the CRM user mapped to the sender's Telegram ID

**Success response:**
```
✅ Contact added

Rajesh Sharma
CTO @ InfraSec Solutions
📧 rajesh@infrasec.in
📱 9876543210
🏷 ISO 27001, NASSCOM Event
👤 Owner: Atharva

🔗 https://crm.seccomply.com/contacts/uuid-here
```

**Error responses:**
```
❌ Missing required field: name

Format:
/add
name: Full Name
title: Job Title
company: Company Name
email: email@example.com
phone: 9876543210
tags: Tag1, Tag2
notes: Any notes
source: manual
```

```
❌ Unauthorized

Your Telegram account is not linked to a CRM user.
Contact your admin to set up access.
```

---

### Command: `/addcompany` — Add a Company

**Format:**
```
/addcompany
name: InfraSec Solutions
domain: infrasec.in
industry: IT Services
size: 51-200
type: prospect
phone: 02012345678
city: Pune
country: India
tags: BFSI, Manufacturing
notes: Potential enterprise client
```

**Required:** `name`  
**Optional:** All others.

**Parsing:** Same key:value parsing. `size` must match enum (1-10, 11-50, 51-200, etc.). `type` must match enum (prospect, customer, partner, vendor, competitor). `domain` is normalized (strip http/https/www).

**Success response:**
```
✅ Company added

InfraSec Solutions
🌐 infrasec.in
🏢 IT Services · 51-200 employees
📍 Pune, India
🏷 BFSI, Manufacturing

🔗 https://crm.seccomply.com/companies/uuid-here
```

---

### Command: `/note` — Log a Note Against a Contact

**Format:**
```
/note
contact: rajesh@infrasec.in
type: call
subject: Follow-up call on SOC 2 proposal
body: Rajesh confirmed budget approval. Moving to negotiation stage. Wants pricing for 2-year contract.
duration: 15
outcome: connected
```

**Required:** `contact` (email or full name) + `body` (or `subject` at minimum)  
**Optional:** `type` (defaults to `note`), `subject`, `duration` (minutes, for calls), `outcome` (for calls)

**Contact lookup:** First try exact email match. If not found, try name match (case-insensitive, `first_name || ' ' || last_name ILIKE input`). If multiple matches, return a list and ask user to specify by email.

**Valid types:** call, email_sent, email_received, meeting, note, whatsapp, linkedin, demo, proposal, custom  
**Valid outcomes (for calls):** connected, voicemail, no_answer, busy, wrong_number

**Success response:**
```
✅ Note logged

📞 Call — Follow-up call on SOC 2 proposal
👤 Rajesh Sharma @ InfraSec Solutions
⏱ 15 min · Connected
📝 Rajesh confirmed budget approval...

🔗 https://crm.seccomply.com/contacts/uuid#activities
```

**Ambiguous contact response:**
```
⚠️ Multiple contacts found for "Rajesh":

1. Rajesh Sharma — rajesh@infrasec.in
2. Rajesh Patel — rajesh.patel@techcorp.com

Reply with the email of the correct contact.
```

---

### Command: `/log` — Quick Call/Meeting Log

Shorthand for `/note` with `type: call` preset:

```
/log
contact: rajesh@infrasec.in
duration: 10
outcome: voicemail
notes: Left voicemail about proposal follow-up
```

**Equivalent to `/note` with `type: call`.**

---

### Command: `/find` — Look Up a Contact or Company

**Format:**
```
/find rajesh@infrasec.in
```
or
```
/find InfraSec Solutions
```
or
```
/find Rajesh Sharma
```

**Single argument after command.** System searches contacts first (by email, then name), then companies (by name, then domain).

**Response (contact found):**
```
👤 Rajesh Sharma
CTO @ InfraSec Solutions
📧 rajesh@infrasec.in
📱 9876543210
📊 Status: Contacted · Score: 45
🏷 ISO 27001, NASSCOM Event
👤 Owner: Atharva
📅 Last contacted: 2 days ago
💰 2 open deals (₹8,50,000 pipeline)

🔗 https://crm.seccomply.com/contacts/uuid-here
```

**Response (company found):**
```
🏢 InfraSec Solutions
🌐 infrasec.in
🏢 IT Services · 51-200 employees
📍 Pune, India
👥 4 contacts · 2 open deals
💰 Pipeline: ₹12,00,000
📅 Last activity: 1 day ago

🔗 https://crm.seccomply.com/companies/uuid-here
```

**Not found:**
```
🔍 No results found for "rajesh@infrasec.in"

Try searching by email, full name, or company name.
```

---

### Command: `/today` — Daily Metrics Summary

**No arguments needed:**
```
/today
```

**Response:**
```
📊 SecComply CRM — Today's Snapshot
📅 Friday, 4 April 2026

💰 Pipeline
├ Total open: ₹45,20,000 (23 deals)
├ Weighted: ₹18,75,000
├ Won this month: ₹6,50,000 (3 deals)
└ Lost this month: ₹2,00,000 (1 deal)

📈 Activity (Today)
├ Calls: 8
├ Emails: 12
├ Meetings: 3
└ Notes: 5

⚠️ Attention
├ Stale deals (no activity >7d): 4
├ Tasks overdue: 2
└ New leads (unassigned): 6

👥 Team Leaderboard (This Week)
1. Aditi — 14 activities, ₹3,00,000 won
2. Atharva — 11 activities, ₹2,50,000 won
3. Shivani — 9 activities, ₹1,00,000 won
```

---

### Command: `/mytasks` — Pending Tasks

```
/mytasks
```

**Response:**
```
📋 Your Pending Tasks

🔴 Overdue
├ Follow up with Rajesh on SOC 2 pricing — Due: 2 Apr
└ Send case study to Priya Mehta — Due: 3 Apr

🟡 Due Today
└ Prepare demo for TechVault meeting — Due: 4 Apr

🟢 Upcoming
├ Send proposal to CloudNine — Due: 7 Apr
└ Schedule call with Anantya.ai — Due: 8 Apr

Total: 5 tasks (2 overdue)
```

---

### Command: `/help` — Show Usage Guide

```
/help
```

**Response:**
```
📖 SecComply CRM Bot — Commands

/add — Add a new contact
/addcompany — Add a new company
/note — Log activity against a contact
/log — Quick call log (shorthand)
/find — Look up a contact or company
/today — Today's metrics snapshot
/mytasks — Your pending tasks
/help — This message

📝 Format for /add:
/add
name: Full Name (required)
title: Job Title
company: Company Name
email: email@example.com
phone: 9876543210
tags: Tag1, Tag2
notes: Any notes
source: manual|event|referral|website|apollo|cold_outreach

📝 Format for /note:
/note
contact: email@example.com (required)
type: call|meeting|note|email_sent|whatsapp
subject: Brief subject line
body: Detailed notes here
duration: 15 (minutes, for calls)
outcome: connected|voicemail|no_answer

All other commands take a single search term.
```

---

## Part 5: Daily Dashboard Digest — Specification

### 5.1 Digest Configuration UI (Settings → Digest Schedules)

Admin page listing all configured digest schedules. Each schedule has:

**Creation form:**
- Name (e.g., "Morning Sales Briefing")
- Dashboard selector (dropdown of all dashboards)
- Schedule: Daily / Weekly (pick day) / Monthly (pick date)
- Time: Time picker (default 09:00 IST)
- Delivery channels (multi-select):
  - Email: Add recipient email addresses (can include non-CRM users like investors)
  - Telegram: Select from registered Telegram users or enter group chat IDs
- Active toggle

**Schedule list:**
- Table showing: Name, Dashboard, Schedule, Channels, Last Sent, Status, Active toggle, Edit/Delete

### 5.2 Digest Content Generation

The digest renderer queries the dashboard's widgets and formats them into two output formats:

**Email format (HTML):**
- Branded header with SecComply logo
- Dashboard title + generation timestamp
- Each widget rendered as a section:
  - Metric cards → Bold number with label and trend arrow (↑12% or ↓5%)
  - Bar/Pie charts → Rendered as an HTML table (since email clients don't support JS charts)
  - Tables → Standard HTML table
  - Funnel → Stepped horizontal bars in HTML/CSS
  - Leaderboard → Numbered list
- Footer with link to live dashboard

**Telegram format (plain text with emoji):**
- Structured text message (like the `/today` response but driven by the dashboard's actual widgets)
- Metric cards → `💰 Total Pipeline: ₹45,20,000`
- Charts → Converted to text summaries (top 5 items from bar charts, percentages from pie charts)
- Tables → Top 5-10 rows only (Telegram message limit is 4096 chars)
- Link to live dashboard at the bottom

### 5.3 Cron Job Implementation

Use `node-cron` (lightweight, no external dependency) running inside the Next.js server process:

- On server startup, load all active digest schedules from database
- Register a cron job for each schedule
- Every minute, a master cron checks if any schedule is due (comparing current IST time to `schedule_time` and `schedule_type`)
- When a schedule is due:
  1. Query all dashboard widgets using the existing dashboard data engine
  2. Render into email HTML and/or Telegram text format
  3. Send via SMTP (nodemailer) and/or Telegram Bot API (`sendMessage`)
  4. Update `last_sent_at` on the schedule record
  5. Log any errors in `last_error`
  6. Write to audit log

**For Railway deployment:** The cron runs inside the same Next.js process — since Railway keeps the process alive 24/7, this works perfectly. No need for external cron services.

### 5.4 Telegram Group Support for Digests

The daily digest can be sent to a Telegram group:
1. Add the bot to the group
2. Send any message in the group
3. The group's chat ID (negative number like `-1001234567890`) appears in `getUpdates`
4. Add that chat ID to the digest schedule's delivery config
5. Bot posts the digest to the group at the scheduled time

This is great for a "Sales War Room" group where the whole team sees the morning briefing.

---

## Part 6: Admin Settings Pages

### Settings → Telegram Integration

**Page sections:**

1. **Bot Status**
   - Shows: Bot username (@seccomply_crm_bot), webhook status (connected/disconnected), last message received timestamp
   - Button: "Test Connection" (sends a test message to the bot and verifies round-trip)

2. **Authorized Users**
   - Table: CRM User | Telegram ID | Telegram Username | Status (Active/Inactive) | Last Active | Actions
   - "Add User" button: Select CRM user → Enter their Telegram ID → Save
   - Each row has: Toggle active/inactive, Remove button
   - Note: Only authorized users can interact with the bot. Unauthorized messages receive a rejection response.

3. **Message Log**
   - Table: Timestamp | User | Command | Message Preview | Status | Entity Created | Actions
   - Filters: User, Command, Status, Date range
   - Click to expand full message and response
   - Useful for debugging and auditing bot interactions

### Settings → Digest Schedules

(Described in Section 5.1 above)

---

## Part 7: File Structure Additions

```
src/
├── server/
│   ├── db/schema/
│   │   ├── telegram-users.ts          # NEW
│   │   ├── digest-schedules.ts        # NEW
│   │   └── telegram-message-log.ts    # NEW
│   ├── services/
│   │   ├── telegram.service.ts        # NEW — Bot message handling, command parsing
│   │   ├── digest.service.ts          # NEW — Dashboard digest generation + delivery
│   │   └── digest-renderer.ts         # NEW — HTML email + Telegram text formatters
│   ├── trpc/routers/
│   │   ├── telegram.router.ts         # NEW — Admin CRUD for telegram users
│   │   └── digest.router.ts           # NEW — Admin CRUD for digest schedules
│   ├── lib/
│   │   ├── telegram-bot.ts            # NEW — Telegram API client wrapper
│   │   ├── telegram-parser.ts         # NEW — Structured message parser
│   │   ├── cron.ts                    # NEW — Cron scheduler for digests
│   │   └── mailer.ts                  # NEW — Nodemailer wrapper
│   └── webhooks/
│       └── telegram.ts                # NEW — Webhook handler
├── app/
│   ├── api/
│   │   └── webhooks/
│   │       └── telegram/route.ts      # NEW — POST endpoint for Telegram webhook
│   └── (dashboard)/
│       └── settings/
│           ├── telegram/page.tsx       # NEW — Telegram integration settings
│           └── digests/page.tsx        # NEW — Digest schedule management
└── components/
    ├── settings/
    │   ├── TelegramUserManager.tsx     # NEW
    │   ├── TelegramMessageLog.tsx      # NEW
    │   ├── DigestScheduleForm.tsx      # NEW
    │   └── DigestScheduleList.tsx      # NEW
    └── shared/
        └── CronSchedulePicker.tsx      # NEW — Reusable schedule selector
```

---

## Part 8: API Contracts

### Telegram Webhook Endpoint

```
POST /api/webhooks/telegram
Header: X-Telegram-Bot-Api-Secret-Token: <TELEGRAM_WEBHOOK_SECRET>
Body: Telegram Update object (JSON)
```

The handler:
1. Validates the secret token header
2. Extracts the message text and sender info
3. Looks up sender's `telegram_user_id` in `telegram_users` table
4. If not found → respond with unauthorized message
5. If found → route to command handler based on first line (`/add`, `/find`, etc.)
6. Command handler parses the structured message, executes CRM operation, returns response text
7. Send response text back via Telegram `sendMessage` API
8. Log everything to `telegram_message_log`

### tRPC Routers

```typescript
// telegram.router.ts
const telegramRouter = router({
    // List authorized Telegram users
    listUsers: adminProcedure.query(/* ... */),
    
    // Add Telegram user mapping
    addUser: adminProcedure
        .input(z.object({
            userId: z.string().uuid(),           // CRM user ID
            telegramUserId: z.number().int(),     // Telegram numeric ID
            telegramUsername: z.string().optional(),
        }))
        .mutation(/* ... */),
    
    // Remove Telegram user mapping
    removeUser: adminProcedure
        .input(z.object({ id: z.string().uuid() }))
        .mutation(/* ... */),
    
    // Toggle active/inactive
    toggleActive: adminProcedure
        .input(z.object({ id: z.string().uuid(), isActive: z.boolean() }))
        .mutation(/* ... */),
    
    // Get message log
    getMessageLog: adminProcedure
        .input(z.object({
            filters: z.object({
                userId: z.string().uuid().optional(),
                command: z.string().optional(),
                status: z.enum(['success', 'error', 'unauthorized', 'invalid_format']).optional(),
                dateRange: z.object({ from: z.date(), to: z.date() }).optional(),
            }).optional(),
            pagination: z.object({ cursor: z.string().optional(), limit: z.number().default(50) }),
        }))
        .query(/* ... */),
    
    // Test bot connection
    testConnection: adminProcedure.mutation(/* ... */),
    
    // Get bot status
    getBotStatus: adminProcedure.query(/* ... */),
});

// digest.router.ts
const digestRouter = router({
    // List all digest schedules
    list: adminProcedure.query(/* ... */),
    
    // Create digest schedule
    create: adminProcedure
        .input(z.object({
            name: z.string().min(1).max(150),
            dashboardId: z.string().uuid(),
            scheduleType: z.enum(['daily', 'weekly', 'monthly']),
            scheduleTime: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/),  // HH:MM
            scheduleDayOfWeek: z.number().int().min(0).max(6).optional(),
            scheduleDayOfMonth: z.number().int().min(1).max(28).optional(),
            deliveryChannels: z.array(z.union([
                z.object({ type: z.literal('email'), recipients: z.array(z.string().email()) }),
                z.object({ type: z.literal('telegram'), chatIds: z.array(z.number()) }),
            ])),
            isActive: z.boolean().default(true),
        }))
        .mutation(/* ... */),
    
    // Update digest schedule
    update: adminProcedure
        .input(z.object({
            id: z.string().uuid(),
            data: /* same as create schema, all optional */
        }))
        .mutation(/* ... */),
    
    // Delete digest schedule
    delete: adminProcedure
        .input(z.object({ id: z.string().uuid() }))
        .mutation(/* ... */),
    
    // Toggle active/inactive
    toggleActive: adminProcedure
        .input(z.object({ id: z.string().uuid(), isActive: z.boolean() }))
        .mutation(/* ... */),
    
    // Send digest now (manual trigger for testing)
    sendNow: adminProcedure
        .input(z.object({ id: z.string().uuid() }))
        .mutation(/* ... */),
});
```

---

## Part 9: Telegram Message Parser — Implementation Detail

The parser is a pure function — no async, no side effects, fully testable:

```typescript
// telegram-parser.ts

interface ParsedMessage {
    command: string;
    fields: Record<string, string>;
    errors: string[];
}

function parseStructuredMessage(rawText: string): ParsedMessage {
    const lines = rawText.trim().split('\n').map(l => l.trim()).filter(Boolean);
    
    if (lines.length === 0) {
        return { command: '', fields: {}, errors: ['Empty message'] };
    }
    
    // First line is the command
    const command = lines[0].toLowerCase().split(/\s/)[0];  // '/add', '/note', etc.
    
    // For single-argument commands like /find
    if (['/find'].includes(command)) {
        const searchTerm = rawText.replace(command, '').trim();
        return { command, fields: { query: searchTerm }, errors: [] };
    }
    
    // For no-argument commands
    if (['/today', '/mytasks', '/help', '/start'].includes(command)) {
        return { command, fields: {}, errors: [] };
    }
    
    // Parse key: value pairs from remaining lines
    const fields: Record<string, string> = {};
    const errors: string[] = [];
    
    for (let i = 1; i < lines.length; i++) {
        const colonIndex = lines[i].indexOf(':');
        if (colonIndex === -1) {
            errors.push(`Line ${i + 1}: Missing colon separator — "${lines[i]}"`);
            continue;
        }
        const key = lines[i].substring(0, colonIndex).trim().toLowerCase();
        const value = lines[i].substring(colonIndex + 1).trim();
        if (!key) {
            errors.push(`Line ${i + 1}: Empty key`);
            continue;
        }
        if (!value) {
            continue;  // Skip empty values silently
        }
        fields[key] = value;
    }
    
    return { command, fields, errors };
}

// Field-specific parsers

function parseName(nameStr: string): { firstName: string; lastName: string } {
    const parts = nameStr.trim().split(/\s+/);
    if (parts.length === 1) return { firstName: parts[0], lastName: '' };
    const lastName = parts.pop()!;
    return { firstName: parts.join(' '), lastName };
}

function parseTags(tagStr: string): string[] {
    return tagStr.split(',').map(t => t.trim()).filter(Boolean);
}

function parsePhone(phoneStr: string): string {
    return phoneStr.replace(/[^\d+]/g, '');
}

function validateEmail(email: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function normalizeDomain(domain: string): string {
    return domain.replace(/^(https?:\/\/)?(www\.)?/, '').replace(/\/.*$/, '').toLowerCase();
}
```

---

## Part 10: Dependencies to Add

```bash
npm install node-cron nodemailer
npm install -D @types/nodemailer @types/node-cron
```

No additional dependencies needed for the Telegram Bot API — it's a simple HTTPS REST API. Use the built-in `fetch` (Node 18+) to call it. No need for a Telegram bot library — the API is simple enough to call directly:

```typescript
// telegram-bot.ts — Lightweight Telegram API wrapper

const TELEGRAM_API = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;

async function sendMessage(chatId: number, text: string, parseMode: 'HTML' | 'Markdown' = 'HTML') {
    const response = await fetch(`${TELEGRAM_API}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            chat_id: chatId,
            text,
            parse_mode: parseMode,
            disable_web_page_preview: true,
        }),
    });
    return response.json();
}

async function getUpdates(offset?: number) {
    const params = new URLSearchParams({ timeout: '30' });
    if (offset) params.set('offset', String(offset));
    const response = await fetch(`${TELEGRAM_API}/getUpdates?${params}`);
    return response.json();
}

async function setWebhook(url: string, secretToken: string) {
    const response = await fetch(`${TELEGRAM_API}/setWebhook`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url, secret_token: secretToken }),
    });
    return response.json();
}

async function getBotInfo() {
    const response = await fetch(`${TELEGRAM_API}/getMe`);
    return response.json();
}
```

---

## Part 11: Testing Checklist

After building, verify these scenarios:

### Telegram Bot Tests
- [ ] Unauthorized user sends message → receives rejection
- [ ] `/add` with only name → contact created, success response
- [ ] `/add` with all fields → contact + company created, tags applied, success response
- [ ] `/add` with missing name → error response with format hint
- [ ] `/add` with malformed lines (no colon) → error response identifying bad lines
- [ ] `/addcompany` basic → company created
- [ ] `/addcompany` duplicate domain → error or existing company returned
- [ ] `/note` with valid email → activity logged against correct contact
- [ ] `/note` with ambiguous name → disambiguation prompt returned
- [ ] `/find` by email → correct contact returned with stats
- [ ] `/find` by company name → correct company returned
- [ ] `/find` with no results → "not found" message
- [ ] `/today` → metrics snapshot with correct numbers
- [ ] `/mytasks` → tasks for the calling user only (not other users' tasks)
- [ ] `/help` → full format guide
- [ ] Unknown command → "unknown command, try /help"
- [ ] Audit log records all bot-created entities with source = 'telegram'

### Daily Digest Tests
- [ ] Create digest schedule → appears in list
- [ ] "Send Now" → digest delivered to email and/or Telegram
- [ ] Email digest renders correctly (check in email client)
- [ ] Telegram digest stays under 4096 char limit
- [ ] Cron fires at scheduled time (test with 1-minute schedule)
- [ ] Inactive schedule does not fire
- [ ] Failed delivery → error recorded in `last_error`
- [ ] Schedule with Telegram group chat ID → message posted to group

---

**END OF ADDENDUM**
